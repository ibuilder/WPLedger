<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Main plugin bootstrap — wires all components via WordPress hooks.
 *
 * @package LedgerCore
 */

namespace LedgerCore;

use LedgerCore\Rest\RestCompanies;
use LedgerCore\Rest\RestJournal;
use LedgerCore\Rest\RestReports;
use LedgerCore\Rest\RestIntegrations;
use LedgerCore\Admin\AdminMenu;
use LedgerCore\Integrations\WoocommerceSync;
use LedgerCore\Integrations\WcInvoice;

/**
 * Orchestrates hook registration for every plugin subsystem.
 */
class Plugin {

	/**
	 * Register all hooks and bootstrap subsystems.
	 *
	 * @return void
	 */
	public function run(): void {
		add_action( 'init', [ $this, 'load_textdomain' ] );

		// REST API — all routes under ledgercore/v1.
		( new RestCompanies() )->register();
		( new RestJournal() )->register();
		( new RestReports() )->register();
		( new RestIntegrations() )->register();

		// Expose the REST nonce for browser-side wp.apiFetch calls.
		// Priority 11 — must run after enqueue_assets (priority 10) so the script exists.
		add_action( 'admin_enqueue_scripts', [ $this, 'localize_rest_nonce' ], 11 );

		// WooCommerce integration — registers hooks after plugins loaded.
		add_action( 'plugins_loaded', [ $this, 'init_woocommerce' ] );

		// Admin UI — only in admin context.
		if ( is_admin() ) {
			( new AdminMenu() )->register();
		}
	}

	/**
	 * Load the plugin text domain for i18n.
	 *
	 * @return void
	 */
	/**
	 * Initialise WooCommerce integration after all plugins have loaded.
	 *
	 * @return void
	 */
	public function init_woocommerce(): void {
		( new WoocommerceSync() )->register();
		( new WcInvoice() )->register();
	}

	public function load_textdomain(): void {
		load_plugin_textdomain(
			'ledgercore',
			false,
			dirname( plugin_basename( LEDGERCORE_FILE ) ) . '/languages'
		);
	}

	/**
	 * Localize ledgercoreData with the REST nonce for any screen that loads
	 * the admin JS — allows wp.apiFetch to authenticate browser requests.
	 *
	 * @return void
	 */
	public function localize_rest_nonce(): void {
		// Only localize when our admin CSS is enqueued (i.e. on our screens).
		if ( ! wp_script_is( 'ledgercore-admin', 'enqueued' ) ) {
			return;
		}

		wp_localize_script(
			'ledgercore-admin',
			'ledgercoreData',
			[
				'restUrl' => esc_url_raw( rest_url( 'ledgercore/v1/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => [
					'debits'    => __( 'Debits', 'ledgercore' ),
					'credits'   => __( 'Credits', 'ledgercore' ),
					'balanced'  => __( 'Balanced', 'ledgercore' ),
					'unbalanced' => __( 'Unbalanced', 'ledgercore' ),
				],
			]
		);
	}
}
