<?php
/**
 * Admin view: QuickBooks Export.
 *
 * Variables: $companies (array), $company_id (int), $start (string), $end (string)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap lc-wrap">
	<h1><?php esc_html_e( 'QuickBooks Export', 'ledgercore' ); ?></h1>

	<p class="description">
		<?php esc_html_e( 'Export journal entries from your ledger in a format compatible with QuickBooks. Choose the date range and your QuickBooks version, then click Download.', 'ledgercore' ); ?>
	</p>

	<table class="form-table" style="max-width:600px">
		<tr>
			<th scope="row"><?php esc_html_e( 'QuickBooks Desktop (IIF)', 'ledgercore' ); ?></th>
			<td>
				<p class="description">
					<?php esc_html_e( 'Intuit Interchange Format — imports into QuickBooks Pro, Premier, and Enterprise via File → Utilities → Import → IIF Files.', 'ledgercore' ); ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'lc_export_qb' ); ?>
					<input type="hidden" name="action" value="lc_export_qb">
					<input type="hidden" name="format" value="iif">
					<?php echo $company_selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<label><?php esc_html_e( 'From:', 'ledgercore' ); ?>
						<input type="date" name="start" value="<?php echo esc_attr( $start ); ?>" required>
					</label>
					&nbsp;
					<label><?php esc_html_e( 'To:', 'ledgercore' ); ?>
						<input type="date" name="end" value="<?php echo esc_attr( $end ); ?>" required>
					</label>
					<br><br>
					<?php submit_button( __( 'Download IIF', 'ledgercore' ), 'primary', 'submit', false ); ?>
				</form>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'QuickBooks Online (CSV)', 'ledgercore' ); ?></th>
			<td>
				<p class="description">
					<?php esc_html_e( 'General Journal CSV — imports into QuickBooks Online via Accountant → Journal Entries → Import.', 'ledgercore' ); ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'lc_export_qb' ); ?>
					<input type="hidden" name="action" value="lc_export_qb">
					<input type="hidden" name="format" value="csv">
					<?php echo $company_selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<label><?php esc_html_e( 'From:', 'ledgercore' ); ?>
						<input type="date" name="start" value="<?php echo esc_attr( $start ); ?>" required>
					</label>
					&nbsp;
					<label><?php esc_html_e( 'To:', 'ledgercore' ); ?>
						<input type="date" name="end" value="<?php echo esc_attr( $end ); ?>" required>
					</label>
					<br><br>
					<?php submit_button( __( 'Download CSV', 'ledgercore' ), 'secondary', 'submit', false ); ?>
				</form>
			</td>
		</tr>
	</table>

	<hr>
	<h2><?php esc_html_e( 'Import Instructions', 'ledgercore' ); ?></h2>
	<h3><?php esc_html_e( 'QuickBooks Desktop (IIF)', 'ledgercore' ); ?></h3>
	<ol>
		<li><?php esc_html_e( 'In QuickBooks Desktop, go to File → Utilities → Import → IIF Files.', 'ledgercore' ); ?></li>
		<li><?php esc_html_e( 'Select the downloaded .iif file and click Open.', 'ledgercore' ); ?></li>
		<li><?php esc_html_e( 'QuickBooks will import the chart of accounts and journal entries. Review the transaction journal after import.', 'ledgercore' ); ?></li>
	</ol>
	<h3><?php esc_html_e( 'QuickBooks Online (CSV)', 'ledgercore' ); ?></h3>
	<ol>
		<li><?php esc_html_e( 'In QuickBooks Online, go to Accounting → Chart of Accounts and ensure the account names match the exported codes.', 'ledgercore' ); ?></li>
		<li><?php esc_html_e( 'Go to Accountant → Journal Entries and look for an Import option, or use the CSV import tool in your Accountant view.', 'ledgercore' ); ?></li>
		<li><?php esc_html_e( 'Select the downloaded .csv file. Map the columns as prompted.', 'ledgercore' ); ?></li>
	</ol>
	<p class="description">
		<?php esc_html_e( 'Tip: always reconcile your QB ledger against the LedgerCore statements after import to confirm the totals match.', 'ledgercore' ); ?>
	</p>
</div>
