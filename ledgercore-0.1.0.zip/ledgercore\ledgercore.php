<?php
/**
 * Plugin Name:       LedgerCore Accounting
 * Plugin URI:        https://wordpress.org/plugins/ledgercore
 * Description:       Double-entry accounting for WordPress: chart of accounts, journal entries, Balance Sheet, Income Statement, Cash Flow Statement, PDF export, and a REST API for invoicing and project-management integrations.
 * Version:           0.1.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            LedgerCore
 * Author URI:        https://wordpress.org/plugins/ledgercore
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ledgercore
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LEDGERCORE_VERSION', '0.1.0' );
define( 'LEDGERCORE_FILE', __FILE__ );
define( 'LEDGERCORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'LEDGERCORE_URL', plugin_dir_url( __FILE__ ) );

/**
 * Display an admin notice when Composer dependencies have not been installed.
 *
 * @return void
 */
function ledgercore_missing_vendor_notice() {
	echo '<div class="notice notice-error"><p><strong>LedgerCore:</strong> '
		. esc_html__( 'Composer dependencies are missing. Run "composer install" inside the plugin directory.', 'ledgercore' )
		. '</p></div>';
}

$ledgercore_autoload = LEDGERCORE_DIR . 'vendor/autoload.php';
if ( ! file_exists( $ledgercore_autoload ) ) {
	add_action( 'admin_notices', 'ledgercore_missing_vendor_notice' );
	return;
}
require_once $ledgercore_autoload;

register_activation_hook( __FILE__, [ 'LedgerCore\\Activator', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'LedgerCore\\Deactivator', 'deactivate' ] );

add_action( 'plugins_loaded', function () {
	( new LedgerCore\Plugin() )->run();
} );
