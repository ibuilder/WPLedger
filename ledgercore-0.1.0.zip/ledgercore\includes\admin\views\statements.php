<?php
/**
 * Admin view: Financial Statements viewer.
 *
 * Variables: $companies, $company_id, $statement, $as_of, $start, $end, $data
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$fmt = fn( $v ) => number_format( (float) $v, 2 );
?>
<div class="wrap lc-wrap">
	<h1><?php esc_html_e( 'Financial Statements', 'ledgercore' ); ?></h1>

	<form method="get" style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
		<input type="hidden" name="page" value="lc-statements">
		<select name="company_id" onchange="this.form.submit()">
			<option value=""><?php esc_html_e( '— Company —', 'ledgercore' ); ?></option>
			<?php foreach ( $companies as $c ) : ?>
				<option value="<?php echo absint( $c->id ); ?>" <?php selected( $company_id, $c->id ); ?>><?php echo esc_html( $c->name ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="statement">
			<option value="balance_sheet"    <?php selected( $statement, 'balance_sheet' ); ?>><?php esc_html_e( 'Balance Sheet', 'ledgercore' ); ?></option>
			<option value="income_statement" <?php selected( $statement, 'income_statement' ); ?>><?php esc_html_e( 'Income Statement', 'ledgercore' ); ?></option>
			<option value="cash_flow"        <?php selected( $statement, 'cash_flow' ); ?>><?php esc_html_e( 'Cash Flow', 'ledgercore' ); ?></option>
		</select>
		<?php if ( 'balance_sheet' === $statement ) : ?>
			<label><?php esc_html_e( 'As of:', 'ledgercore' ); ?> <input type="date" name="as_of" value="<?php echo esc_attr( $as_of ); ?>"></label>
		<?php else : ?>
			<label><?php esc_html_e( 'From:', 'ledgercore' ); ?> <input type="date" name="start" value="<?php echo esc_attr( $start ); ?>"></label>
			<label><?php esc_html_e( 'To:', 'ledgercore' ); ?>   <input type="date" name="end"   value="<?php echo esc_attr( $end ); ?>"></label>
		<?php endif; ?>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'View', 'ledgercore' ); ?></button>
	</form>

	<?php if ( $data && isset( $data['error'] ) ) : ?>
		<div class="notice notice-error"><p><?php echo esc_html( $data['error'] ); ?></p></div>
	<?php elseif ( $data ) : ?>

		<?php /* PDF download buttons — served via admin-post.php, not the REST API */ ?>
		<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">

			<?php /* Download current statement */ ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'lc_download_report' ); ?>
				<input type="hidden" name="action"     value="lc_download_report">
				<input type="hidden" name="company_id" value="<?php echo absint( $company_id ); ?>">
				<input type="hidden" name="report"     value="<?php echo esc_attr( $statement ); ?>">
				<input type="hidden" name="as_of"      value="<?php echo esc_attr( $as_of ); ?>">
				<input type="hidden" name="start"      value="<?php echo esc_attr( $start ); ?>">
				<input type="hidden" name="end"        value="<?php echo esc_attr( $end ); ?>">
				<button type="submit" class="button">
					<?php esc_html_e( '⬇ Download This Statement (PDF)', 'ledgercore' ); ?>
				</button>
			</form>

			<?php /* Download all three statements as one PDF package */ ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'lc_download_report' ); ?>
				<input type="hidden" name="action"     value="lc_download_report">
				<input type="hidden" name="company_id" value="<?php echo absint( $company_id ); ?>">
				<input type="hidden" name="report"     value="financial_package">
				<input type="hidden" name="as_of"      value="<?php echo esc_attr( $as_of ); ?>">
				<input type="hidden" name="start"      value="<?php echo esc_attr( $start ); ?>">
				<input type="hidden" name="end"        value="<?php echo esc_attr( $end ); ?>">
				<button type="submit" class="button button-secondary">
					<?php esc_html_e( '⬇ Download Full Package (PDF)', 'ledgercore' ); ?>
				</button>
			</form>

		</div>

		<?php if ( 'balance_sheet' === $statement ) : ?>
			<h2><?php esc_html_e( 'Balance Sheet', 'ledgercore' ); ?> — <?php echo esc_html( $data['as_of'] ); ?>
				<?php if ( ! $data['balanced'] ) : ?>
					<span style="color:red"> ⚠ <?php esc_html_e( 'NOT BALANCED', 'ledgercore' ); ?></span>
				<?php endif; ?>
			</h2>
			<table class="widefat lc-statement">
				<tbody>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'ASSETS', 'ledgercore' ); ?></td></tr>
					<tr><td colspan="2"><em><?php esc_html_e( 'Current Assets', 'ledgercore' ); ?></em></td></tr>
					<?php foreach ( $data['current_assets']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Total Current Assets', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['current_assets']['total'] ) ); ?></td></tr>
					<tr><td colspan="2"><em><?php esc_html_e( 'Non-Current Assets', 'ledgercore' ); ?></em></td></tr>
					<?php foreach ( $data['noncurrent_assets']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-total"><td><?php esc_html_e( 'TOTAL ASSETS', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['total_assets'] ) ); ?></td></tr>

					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'LIABILITIES', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['current_liabilities']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<?php foreach ( $data['noncurrent_liabilities']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Total Liabilities', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['total_liabilities'] ) ); ?></td></tr>

					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'EQUITY', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['equity']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr><td class="lc-indent"><?php esc_html_e( 'Current Year Earnings', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['current_year_earnings'] ) ); ?></td></tr>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Total Equity', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['total_equity'] ) ); ?></td></tr>

					<tr class="lc-total"><td><?php esc_html_e( 'TOTAL LIABILITIES & EQUITY', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['total_liab_and_equity'] ) ); ?></td></tr>
				</tbody>
			</table>

		<?php elseif ( 'income_statement' === $statement ) : ?>
			<h2><?php esc_html_e( 'Income Statement', 'ledgercore' ); ?> — <?php echo esc_html( $data['period']['start'] ); ?> <?php esc_html_e( 'to', 'ledgercore' ); ?> <?php echo esc_html( $data['period']['end'] ); ?></h2>
			<table class="widefat lc-statement">
				<tbody>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'REVENUE', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['revenue']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Gross Profit', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['gross_profit'] ) ); ?></td></tr>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'OPERATING EXPENSES', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['operating_expenses']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['name'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Operating Income', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['operating_income'] ) ); ?></td></tr>
					<tr class="lc-total"><td><?php esc_html_e( 'NET INCOME', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['net_income'] ) ); ?></td></tr>
				</tbody>
			</table>

		<?php elseif ( 'cash_flow' === $statement ) : ?>
			<h2><?php esc_html_e( 'Cash Flow Statement', 'ledgercore' ); ?> — <?php echo esc_html( $data['period']['start'] ); ?> <?php esc_html_e( 'to', 'ledgercore' ); ?> <?php echo esc_html( $data['period']['end'] ); ?>
				<?php if ( ! $data['reconciles'] ) : ?>
					<span style="color:red"> ⚠ <?php esc_html_e( 'DOES NOT RECONCILE', 'ledgercore' ); ?></span>
				<?php endif; ?>
			</h2>
			<table class="widefat lc-statement">
				<tbody>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'OPERATING ACTIVITIES', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['operating']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['label'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Net Cash from Operating', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['operating']['total'] ) ); ?></td></tr>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'INVESTING ACTIVITIES', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['investing']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['label'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Net Cash from Investing', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['investing']['total'] ) ); ?></td></tr>
					<tr class="lc-section"><td colspan="2"><?php esc_html_e( 'FINANCING ACTIVITIES', 'ledgercore' ); ?></td></tr>
					<?php foreach ( $data['financing']['rows'] as $r ) : ?>
						<tr><td class="lc-indent"><?php echo esc_html( $r['label'] ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $r['amount'] ) ); ?></td></tr>
					<?php endforeach; ?>
					<tr class="lc-subtotal"><td><?php esc_html_e( 'Net Cash from Financing', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['financing']['total'] ) ); ?></td></tr>
					<tr class="lc-total"><td><?php esc_html_e( 'NET CHANGE IN CASH', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['net_change_in_cash'] ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'Beginning Cash', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['beginning_cash'] ) ); ?></td></tr>
					<tr class="lc-total"><td><?php esc_html_e( 'Ending Cash', 'ledgercore' ); ?></td><td class="lc-amt"><?php echo esc_html( $fmt( $data['ending_cash'] ) ); ?></td></tr>
				</tbody>
			</table>
		<?php endif; ?>

	<?php endif; ?>
</div>
